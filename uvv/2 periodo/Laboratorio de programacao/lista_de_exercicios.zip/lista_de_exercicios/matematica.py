def dobro(n):
    return  n * 2

def triplo(n):
    return  n * 3

def raiz_quadro(n):
    return  n * n

