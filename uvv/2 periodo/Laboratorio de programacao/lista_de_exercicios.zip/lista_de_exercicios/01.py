nome: str = input("Digite seu nome: ")
cargo: str = input("Digite seu cargo: ")
print(f"O colaborador {nome} foi cadastrado com o cargo de {cargo}")