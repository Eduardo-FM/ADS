def boasvindas(nome):
    print("ola " + nome + " seja bem vindo")

