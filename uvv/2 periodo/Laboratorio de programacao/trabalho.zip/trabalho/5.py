# A saída do programa será: 1 2 3 4 5

for i in range(1, 6):
    print(i, end=" ")