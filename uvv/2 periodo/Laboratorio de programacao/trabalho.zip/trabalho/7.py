num = int(input("Digite um número: "))

for i in range(0, num + 1, 2):
    print(i)