#correcão do codigo

numero = int(input("Digite um número: "))
resultado = numero * 2
print("O dobro é:", resultado)
