lista = [3, 7, 2, 9]
print(lista[0])
print(lista[-1])
print(len(lista))