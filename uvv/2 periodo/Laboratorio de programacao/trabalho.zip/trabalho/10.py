lista = []
for i in range(0,5):
    n = int(input("Digite um numero: "))
    lista.append(n)

print(lista)
print(max(lista))
print(min(lista))
