i = 1
while i <= 5:
    print(i)
    i+=1 # O programa não possua uma estrutura para encrementar o i, logo o programa não sabia quando parar.
