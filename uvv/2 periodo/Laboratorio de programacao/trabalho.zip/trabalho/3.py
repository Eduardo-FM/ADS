x = int(input("Digite um número: "))
print(x + 3)
print(x * 2)
print(x % 2)