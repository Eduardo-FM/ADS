num1 = int(input("Digite um número: "))
num2 = int(input("Digite um número: "))

#Soma
print(f"Soma: {num1 + num2}")

#Subtracao
print(f"Subtracao: {num1 - num2}")

#Produto
print(f"Pruduto: {num1 * num2}")

#Quociente
print(f"Quociente: {num1 % num2}")
